module and package

k.py

python 2.x
package is a directory consisting of __init__.py file

python 3.x 
consisting of __init__.py file is optional

